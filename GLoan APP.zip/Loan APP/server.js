const express = require('express');
const mysql = require('mysql2'); // Using mysql2 for promises (though async/await not used here)
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path'); // For serving static files

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json()); // Parse JSON request bodies
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded bodies
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files from the 'public' directory

// MySQL connection pool (recommended for production)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // <<< IMPORTANT: Replace with your MySQL username
    password: '1234', // <<< IMPORTANT: Replace with your MySQL password
    database: 'loan_app'
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL:', err.stack);
        return;
    }
    console.log('Connected to MySQL database as ID ' + db.threadId);
});

// --- API Endpoints ---

// 1. User Signup
app.post('/api/signup', (req, res) => {
    const { email, password, mobile } = req.body;

    if (!email || !password || !mobile) {
        return res.status(400).json({ message: 'Email, password, and mobile are required.' });
    }

    // IMPORTANT: In a real application, hash the password before storing!
    const sql = "INSERT INTO users (email, password, mobile) VALUES (?, ?, ?)";
    db.query(sql, [email, password, mobile], (err, result) => {
        if (err) {
            console.error('Error during signup:', err);
            if (err.code === 'ER_DUP_ENTRY') { // MySQL error code for duplicate entry
                return res.status(409).json({ message: 'Email already registered.' });
            }
            return res.status(500).json({ message: 'Signup failed due to server error.' });
        }
        res.status(201).json({ message: 'User created successfully!', userId: result.insertId });
    });
});

// 2. User Login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required.' });
    }

    // IMPORTANT: In a real application, compare hashed passwords!
    const sql = "SELECT id, email FROM users WHERE email = ? AND password = ?";
    db.query(sql, [email, password], (err, results) => {
        if (err) {
            console.error('Error during login query:', err);
            return res.status(500).json({ message: 'Login failed due to server error.' });
        }
        if (results.length === 0) {
            return res.status(401).json({ message: 'Invalid email or password.' });
        }
        // Basic authentication: send user ID back.
        // In a real app, generate a JWT token here and send it back.
        res.status(200).json({ message: "Login successful", userId: results[0].id });
    });
});

// Middleware to check if user is logged in (basic check for demo)
// In a real app, this would validate a JWT token or session.
const checkAuth = (req, res, next) => {
    const userId = req.headers['x-user-id']; // Get user ID from custom header
    if (!userId) {
        return res.status(401).json({ message: 'Unauthorized: User ID missing.' });
    }
    req.userId = userId; // Attach userId to request object
    next();
};

// 3. Submit Loan Application (Protected Route - basic protection)
app.post('/api/apply-loan', checkAuth, (req, res) => {
    const { loanType, purpose, panNumber, requestedLoanAmount, monthlyEmi, totalInterest, principalAmount, totalAmountPayable, idProofFileName } = req.body;
    const userId = req.userId; // Get user ID from checkAuth middleware

    if (!loanType || !purpose || !panNumber || !requestedLoanAmount) {
        return res.status(400).json({ message: 'Missing required loan application fields.' });
    }

    const sql = `INSERT INTO loan_applications
                 (user_id, loan_type, purpose, pan_number, requested_loan_amount,
                 monthly_emi, total_interest, principal_amount, total_amount_payable, id_proof_filename, status, repayment_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    const values = [
        userId, loanType, purpose, panNumber, requestedLoanAmount,
        monthlyEmi, totalInterest, principalAmount, totalAmountPayable, idProofFileName, 'Pending', '-'
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error submitting loan application:', err);
            return res.status(500).json({ message: 'Loan application failed due to server error.' });
        }
        res.status(201).json({ message: 'Loan application submitted successfully!', applicationId: result.insertId });
    });
});

// 4. Get Loan Status for a User (Protected Route - basic protection)
app.get('/api/loan-status', checkAuth, (req, res) => {
    const userId = req.userId; // Get user ID from checkAuth middleware

    const sql = `SELECT id as applicationId, applied_date, loan_type, status, repayment_status as repayment 
                 FROM loan_applications WHERE user_id = ? ORDER BY applied_date DESC`;
    db.query(sql, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching loan status:', err);
            return res.status(500).json({ message: 'Error fetching loan status.' });
        }
        // Format applied_date to be consistent with previous Firebase output if needed
        const formattedResults = results.map(app => ({
            ...app,
            applied_date: new Date(app.applied_date).toLocaleDateString() // Format date for frontend
        }));
        res.status(200).json(formattedResults);
    });
});

// 5. Get All Loan Applications for Admin (Protected Route - basic protection)
// IMPORTANT: In a real application, you would add a robust admin role check here!
app.get('/api/admin/applications', checkAuth, (req, res) => {
    // For this demo, any logged-in user can access this.
    // In production, ensure only actual admin users can access this.

    const sql = `SELECT la.id as applicationId, la.user_id, u.email as user_email,
                 la.loan_type, la.applied_date, la.status, la.repayment_status as repayment
                 FROM loan_applications la JOIN users u ON la.user_id = u.id ORDER BY la.applied_date DESC`;
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching admin applications:', err);
            return res.status(500).json({ message: 'Error fetching admin applications.' });
        }
        const formattedResults = results.map(app => ({
            ...app,
            applied_date: new Date(app.applied_date).toLocaleDateString(), // Format date
            user: app.user_email // Use 'user' for consistency with previous frontend 'User' column
        }));
        res.status(200).json(formattedResults);
    });
});


// 6. Update Loan Application Status by Admin (Protected Route - basic protection)
// IMPORTANT: In a real application, you would add a robust admin role check here!
app.put('/api/admin/applications/:id/status', checkAuth, (req, res) => {
    const { id } = req.params;
    const { status, repayment } = req.body;

    if (!status) {
        return res.status(400).json({ message: 'Status is required.' });
    }

    const sql = `UPDATE loan_applications SET status = ?, repayment_status = ? WHERE id = ?`;
    db.query(sql, [status, repayment || '-', id], (err, result) => {
        if (err) {
            console.error('Error updating application status:', err);
            return res.status(500).json({ message: 'Error updating application status.' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Application not found.' });
        }
        res.status(200).json({ message: `Application ${id} status updated to ${status}.` });
    });
});

// Serve the index.html for any unmatched routes (SPA-like behavior, for fallback)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Serving static files from: ${path.join(__dirname, 'public')}`);
});