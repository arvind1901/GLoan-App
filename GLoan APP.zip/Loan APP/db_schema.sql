-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS loan_app;

-- Use the database
USE loan_app;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- In a real app, hash this password!
    mobile VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create loan_applications table
CREATE TABLE IF NOT EXISTS loan_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    loan_type VARCHAR(50) NOT NULL,
    purpose TEXT NOT NULL,
    pan_number VARCHAR(10) NOT NULL,
    requested_loan_amount DECIMAL(15, 2) NOT NULL,
    monthly_emi DECIMAL(15, 2),
    total_interest DECIMAL(15, 2),
    principal_amount DECIMAL(15, 2),
    total_amount_payable DECIMAL(15, 2),
    id_proof_filename VARCHAR(255), -- Storing filename, actual file needs separate storage
    status VARCHAR(50) DEFAULT 'Pending', -- e.g., 'Pending', 'Approved', 'Rejected'
    repayment_status VARCHAR(50) DEFAULT '-', -- e.g., 'Paid', 'Due', '-'
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Optional: Create an admin user (for testing admin page)
-- In a real app, manage roles properly.
-- INSERT INTO users (email, password) VALUES ('admin@example.com', 'adminpass');